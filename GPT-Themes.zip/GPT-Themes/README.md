# GPT Themes

GPT Themes is a Windows control-panel app for skinning the ChatGPT Desktop app at runtime. It lets you choose built-in or custom themes, tune layout and glass settings, use local background/panel images, preview the result, then apply the selected theme to ChatGPT Desktop through a localhost Chromium debugging connection.

Local documentation:

- `docs/user-guide.html`
- `docs/developer-guide.html`

## Features

- Built-in theme cards plus a custom theme editor.
- Live preview for theme colors, panel images, background images, layout, glass, and font settings.
- Layout modes: Standard, Wide, Compact, and Focus.
- Glass level and Glass Search controls.
- Local background image and panel image support with color fallbacks when files are missing.
- Apply Theme, Clear Theme, Watch On/Off, Test Port, and Relaunch with Port actions.
- Save, Save As, Import, and Export for manually editable theme files.
- Automatic ChatGPT Desktop detection with manual executable selection as fallback.

## Installation

Use the installer when you want Start Menu integration and uninstall support:

```text
release\GPT-Themes-Setup.exe
```

The installer copies the runtime files to:

```text
%LOCALAPPDATA%\Programs\GPT Themes
```

It includes the app executable, required assets, `themes.json`, `README.md`, and the local HTML guides under `docs\`. It creates Start Menu shortcuts and offers a Desktop shortcut option. Uninstall is available from Windows Apps settings or the Start Menu uninstall shortcut.

For a ZIP release, extract:

```text
release\GPT-Themes.zip
```

Then run:

```text
GPT-Themes\GPT Themes.exe
```

## Usage

1. Open GPT Themes.
2. Select a theme card or edit colors/settings.
3. Confirm the Live Preview looks right.
4. Click `Apply Theme`.

Theme cards, sliders, color controls, and image pickers update only the GPT Themes preview and saved editor state. They do not inject into ChatGPT Desktop until `Apply Theme` is clicked. `Watch: Off` means no background reapply loop is running.

## Theme System

Theme files use the `.gpttheme` extension and contain UTF-8 JSON. Saving a theme automatically appends `.gpttheme` when no extension is typed.

The saved document shape is:

```json
{
  "Format": "gpt-themes.theme",
  "Version": 1,
  "Theme": {
    "Id": "custom",
    "Name": "Custom",
    "Bg": "#0B0F19",
    "Panel": "#171B24",
    "Input": "#202634",
    "Text": "#F7F8FB",
    "Accent": "#0A84FF",
    "Border": "#7D8596",
    "User": "#D9ECFF"
  },
  "Settings": {
    "ThemeId": "custom",
    "Layout": "Wide",
    "FontFamily": "Default",
    "Transparency": 35,
    "GlassSearch": true,
    "BackgroundMode": "solid",
    "BackgroundValue": "",
    "PanelImageMode": "off",
    "PanelImageValue": ""
  }
}
```

Exported/shareable themes omit local ChatGPT executable paths and local image paths.

## Apply Theme Workflow

`Apply Theme` checks whether ChatGPT Desktop is reachable on the configured localhost port. If it is not reachable, GPT Themes attempts to detect and launch ChatGPT Desktop with the required debugging flags, waits for the port, then injects the selected CSS.

If launch or port connection fails, GPT Themes shows a status error instead of silently doing nothing. Use `Relaunch with Port` if ChatGPT is open but not on the expected debugging port.

## Security Considerations

GPT Themes does not modify OpenAI servers or the official app package. It injects CSS into the local ChatGPT Desktop Chromium page.

The connection is local:

```text
GPT Themes -> 127.0.0.1:9322 -> ChatGPT Desktop Chromium page
```

Keep the debugging address bound to `127.0.0.1`. Do not expose the port to a LAN, VPN, container bridge, or port forward. GPT Themes validates that the selected port belongs to a ChatGPT Desktop process before injection, but any local debugging port should still be treated as sensitive while open.

## Debugging Port Explanation

ChatGPT Desktop does not currently provide a public local theming API, so GPT Themes uses Chromium DevTools Protocol over localhost. The app starts or relaunches ChatGPT with:

```text
--remote-debugging-address=127.0.0.1 --remote-debugging-port=9322
```

Do not replace this with named pipes or pipe-based communication. The supported workflow is the localhost Chromium debugging port.

## Troubleshooting

- If ChatGPT is closed, click `Apply Theme`; GPT Themes should launch it and apply after the port is reachable.
- If ChatGPT is already open without the port, click `Relaunch with Port`.
- If auto-detection fails, use the manual ChatGPT.exe chooser as a fallback.
- If a background or panel image is missing, GPT Themes falls back to theme colors instead of breaking layout.
- If text becomes hard to read in ChatGPT, reduce glass/transparency or choose a higher-contrast Text color.
- If a saved file has the wrong name, use Save Theme As again; new saves append `.gpttheme` automatically.

## Developer/Build Notes

Main source:

```text
ChatGptDesktopSkinner.cs
```

Build and installer files:

```text
scripts\build-release.ps1
installer\GptThemesSetup.cs
installer\install.cmd
installer\uninstall.cmd
```

Build locally with:

```powershell
.\scripts\build-release.ps1
```

The build uses the Windows .NET Framework C# compiler and creates a managed Windows installer.

## ZIP/Release Notes

Release output is intentionally named consistently:

```text
release\GPT-Themes.zip
release\GPT-Themes-Setup.exe
release\SHA256SUMS
```

`GPT-Themes.zip` contains one top-level `GPT-Themes\` folder with only the runtime files needed to run the app, including `docs\user-guide.html` and `docs\developer-guide.html`.

## Installer Notes

`GPT-Themes-Setup.exe` embeds the clean ZIP payload and installs only the runtime app files. It does not include build caches, staging folders, old ZIPs, unrelated screenshots, or development-only leftovers.

## More Documentation

Open these files locally for the full guides:

- `docs/user-guide.html`
- `docs/developer-guide.html`
